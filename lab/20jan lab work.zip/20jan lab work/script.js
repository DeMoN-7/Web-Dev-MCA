const gender=prompt("Enter you gender")
const age=confirm("Over 60 or not")
if (age){
    console.log("hello ji")
    alert("Adult")
}
else{
    alert("Under 60")
    console.log("hello ji")
}
document.write("your gender:",gender)